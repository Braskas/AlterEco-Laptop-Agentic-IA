# Hooka — identité de marque

Projet de formation (app mobile d'éco-gestes et d'économies). Nom : Hooka. Idée : « Fais un crochet. » (pêche miracle aux bonnes affaires).

- `brand-book/README.md` : brand book complet (logo, couleurs, typo, allégories, accessibilité). Lis-le avant tout travail d'interface.
- `brand-book/01…04-*.md` : plateforme de marque, voix et ton, applications, lexique crochet/pêche.
- `brand-book/tokens.json` (source) et `tokens.css` (variables CSS, thèmes Jour `light` et Nuit `dark`). N'écris jamais de couleur en dur : utilise les variables.
- `brand-book/components/` : `bundle.css` (classes `hk-*`) et un dossier par composant (README + preview.html).
- `assets/logos`, `assets/illustrations` : SVG à plat. Choisis le fichier selon le fond, ne recolore pas.
- `campagne/` : bannière, affiche, pub réseaux 4:5 (HTML autonome).

Règles clés : pas de vert, jaune, bleu ni orange ; aucun animal ; personnages plats sans visage ; aucun emoji ; tutoiement, phrases courtes, zéro culpabilité ; Sora (titres) et Figtree (texte).
