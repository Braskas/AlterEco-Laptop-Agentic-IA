Les allégories de la pêche aux bonnes affaires, en SVG à plat, sans texte et sans animal.

- `etiquette.svg` : l'étiquette accrochée à un hameçon, la prise du jour.
- `telephone-canne.svg` : le téléphone qui lance la ligne.
- `filet.svg` : le filet qui déborde d'étiquettes, de pièces et d'une étincelle.
- `bouchon.svg` : le bouchon, « ça mord ! ».
- `phare.svg` : le phare, les bons plans près de chez toi.
- `seau.svg` : le seau d'étiquettes, les petits pas déjà ramenés.
- `totebag.svg`, `gourde.svg`, `bocal.svg`, `tshirt.svg`, `piece.svg` : les trouvailles.
- `vagues.svg` : bandes d'eau ondulées, 800 × 240.
- `scene-mere.svg` : la scène héroïne, une mère de famille qui pêche une bonne affaire avec son téléphone, son enfant range les prises dans un seau. 800 × 720.

Les vignettes sont carrées (400 ou 300) et reposent sur un disque de couleur douce. Charge-les avec `<img>` ; place titres et prix en HTML par-dessus, jamais dans le SVG.
