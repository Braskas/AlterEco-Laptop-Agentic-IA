Les logos de Hooka, en SVG à plat. Le wordmark est droit, aux terminaisons coupées net : n'y touche pas.

- `hooka-lockup-ink.svg` : wordmark + griffe-hameçon, en `ink` (#17131F). Version principale sur `bg`, `surface`, `brume`, `rose`, `blush` et `lilac`.
- `hooka-lockup-cream.svg` : le même lockup en crème (#F7F4F1), sur `ink` (Jour), sur `bg` (Nuit) et sur `violet` (Jour).
- `hooka-wordmark-ink.svg`, `hooka-wordmark-cream.svg` : le mot seul, quand la hauteur manque.
- `hooka-symbol.svg` : le carré `rose` aux coins très arrondis et à l'hameçon `ink`, pour l'icône d'app, l'avatar et le favicon. Couleurs fixes (#FF3E8E et #17131F) : ne le pose pas sur un fond `rose`.
- `hooka-hook-ink.svg`, `hooka-hook-rose.svg` : l'hameçon seul, comme motif. Il porte toujours une étiquette ou un objet.

Un SVG chargé par `<img>` ne peut pas hériter d'une couleur : choisis le fichier selon le fond, ne recolore pas le logo par CSS.
