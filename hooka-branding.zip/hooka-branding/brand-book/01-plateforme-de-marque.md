# Plateforme de marque

## Raison d'être

Rendre le choix le plus malin aussi le plus simple : celui qui fait du bien à la planète et à ton budget, sans te faire la morale.

## Promesse

Avant de manger, d'acheter ou de te déplacer, Hooka te trouve en 30 secondes l'alternative la moins chère, la plus proche et la plus légère pour la planète.

## Le problème qu'on résout

- Trop d'informations et de contradictions : labels, greenwashing, comparaisons sans fin.
- Pas de temps, pas de budget : on regarde son téléphone par tranches de 30 secondes et le prix décide.
- Une écologie qui culpabilise : des bilans décourageants, sans piste d'action.
- Des apps éparpillées, avec des données parfois périmées.
- Un engagement solitaire, alors qu'on cherche de l'entraide locale.

Le vrai concurrent n'est pas une autre app verte : c'est l'inertie, l'option la plus rapide ou la moins chère.

## Pour qui

Utilisateurs mobiles grand public, environ 25-35 ans, urbains ou péri-urbains, actifs, sensibles à l'écologie mais freinés par le temps, le budget et la complexité. Cinq profils servent de boussole : le débutant (Antoine), le pressé au budget serré (Léa), le parent réaliste (Camille), l'analytique qui veut des sources (Thomas), l'engagé qui cherche du soutien (Sofia).

## Positionnement

> Hooka est le raccourci malin qui transforme un geste pour la planète en bon plan pour ton portefeuille.

| | Les apps très vertes | Hooka |
|---|---|---|
| Univers | Verts, beiges, feuilles, nature | Rose, violet, lilas, noir et blanc cassé, aplats nets, bord de l'eau et pêche aux bonnes affaires |
| Promesse | Mesurer, noter, compenser | Trouver, gagner, foncer |
| Ton | Sérieux, parfois culpabilisant | Complice, vif, drôle, sans leçon |
| Point de départ | Ce qu'on fait de mal | Le prochain petit pas, déjà gagnant |

À valider : ce tableau est une hypothèse issue du pitch. Un audit visuel des apps concurrentes doit le confirmer ou le corriger avant le lancement.

## Idée de marque

**Fais un crochet.** Faire un crochet, c'est se détourner pour trouver mieux ; un hook, c'est un hameçon. La marque est une pêche miracle aux bonnes affaires : l'utilisateur lance la ligne depuis son téléphone et ramène l'alternative la moins chère et la plus légère. Elle quitte le vert des concurrents et ne mise ni sur le jaune, ni sur le bleu, ni sur l'orange : le rose donne l'élan (`rose`), le violet porte l'impact planète (`violet`), le rose pâle montre le gain (`blush`) et le lilas la communauté (`lilac`), sur un blanc cassé neutre et un noir violacé.

## Quatre piliers

1. **Vif.** Une réponse en 30 secondes, un seul geste par écran.
2. **Malin.** Le double bonus : euros gardés et impact évité, affichés ensemble.
3. **Complice.** Zéro culpabilité, de l'entraide, des encouragements qui comptent le positif.
4. **Franc.** Chaque recommandation montre ses critères, ses sources, ses incertitudes et sa date.

## Personnalité

| Hooka est | Hooka n'est pas |
|---|---|
| Complice, comme un ami qui connaît les bons plans | Un coach qui note |
| Vif, il va droit au but | Pressé ou stressant |
| Franc, il montre ses sources et ses doutes | Donneur de leçons |
| Taquin, avec un humour léger | Moqueur, ou drôle aux dépens de l'utilisateur |

## Le nom

**Hooka** = *hook* : l'hameçon, l'accroche, le bon plan, et le crochet qu'on fait pour trouver mieux. La griffe du logo est un hameçon sous le mot. Un « Hook » est la prise : l'alternative que l'app ramène pour toi.

## Signatures

- Signature principale : **Hooka. Fais un crochet, trouve mieux.**
- Preuve : « Le bon réflexe, en 30 secondes. »
- Pub réseaux : « Hooka pêche la prochaine bonne affaire pour toi et la planète. »
- Variantes : « Ça mord près de chez toi. » · « Zéro leçon, que du bon plan. » · « Malin pour toi, bon pour la planète. »

## Lexique de marque

| Fonction du pitch | Nom dans Hooka | Phrase type |
|---|---|---|
| Alternative en 30 secondes | **Hook** | « On t'a trouvé 3 Hooks près de chez toi. » |
| Compteur double bonus | **Double Bonus** | « Ton Double Bonus du mois : 42 € gardés, 38 km de voiture évités. » |
| Tableau de bord positif | **Petits pas** | « 12 petits pas déjà faits. Le prochain ? » |
| Fiche de confiance | **Fiche de confiance** | « Pourquoi ce choix ? Regarde la fiche de confiance. » |
| Cercle local | **La Bande** | « Dans La Bande, Inès donne un manteau taille M. » |
