# Applications

## Icône d'app

Le symbole `hooka-symbol.svg` (carré `rose` aux coins arrondis, hameçon `ink` dont l'œillet porte un point) : lisible dès 32 px, sans texte. Version Nuit : même icône, jamais inversée.

## Écrans clés

| Écran | Composition |
|---|---|
| Accueil | `display-l` « Qu'est-ce qu'il te faut ? », un champ, trois suggestions en pastilles. Fond `bg`, un seul bouton `rose`. |
| Résultats | Trois `HookCard` classées par budget, proximité, temps et impact. Le premier Hook est en `surface`, les autres plus discrets. |
| Fiche de confiance | `TrustSheet` en feuille depuis le bas : critères, sources, incertitudes, date, signalement. |
| Double Bonus | `DoubleBonus` : gain en `blush`, impact en `brume` et `violet`, une équivalence. |
| Petits pas | Liste de ce qui est fait, puis un prochain petit pas. Aucune note qui baisse, aucune série. |
| La Bande | Échanges, achats groupés, covoiturage et bons plans de quartier, en `lilac`. Sans classement ni mise en scène de soi. |

## Campagne « la pêche miracle »

Trois pièces, un seul geste : une ligne lancée, une étiquette ramenée.

| Pièce | Format | Contenu |
|---|---|---|
| Bannière principale | 1920 × 640 | Ligne qui descend du haut, étiquette-hameçon, vagues, titre « Fais un crochet. Trouve mieux. », lockup, bouton « Je fonce ». |
| Affiche | A, portrait 1500 × 2121 | Hameçon géant qui porte une étiquette, vagues, trouvailles, titre « Fais un crochet. Trouve mieux. », signature et lockup. |
| Pub réseaux | 4:5, 1080 × 1350 | Scène de la mère de famille qui pêche les bonnes affaires avec son appli. Titre « Hooka pêche la prochaine bonne affaire pour toi et la planète. », bouton « Je fonce ». |

## Store (App Store et Google Play)

- Nom affiché : Hooka — Bons plans et planète.
- Sous-titre : Fais un crochet, trouve mieux.
- Captures : fond `rose`, `bg` et `brume`, une phrase `display-l` par capture, l'écran dans un cadre sobre avec ombre `lift`.

## Réseaux sociaux

- Format : aplats `rose`, `violet`, `blush`, `lilac`, une allégorie de pêche, une phrase courte en `display-xl`.
- Phrases types : « Une gourde à 6 € près de chez toi. » · « Regarde malin avant d'acheter neuf. » · « 18 € gardés, 6 km évités. Joli coup. »
- Avatar : le symbole. Bannières : wordmark `ink` sur `bg` ou `blush`.

## Goodies

Tote bags, gourdes, cartes postales : un aplat `rose` ou `violet`, le lockup ou l'étiquette-hameçon, rien d'autre. Pas de feuilles.

## Site web

Une page d'accueil en `bg`, titre `display-xl`, un bouton `rose`, trois blocs de couleur pour les trois promesses (vif, malin, complice), puis La Bande en `lilac`.

## Ce que Hooka ne fait pas

Pas de vert ni de feuilles. Aucun animal à l'image : on ne pêche que des bonnes affaires. Pas de mascotte ni d'effet cartoon. Pas de note, de classement ou de série punitive. Pas de photos de stock. Pas de ton moralisateur.
