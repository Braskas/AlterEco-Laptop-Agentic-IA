Le logo de Hooka est le wordmark « hooka » en minuscules géométriques, droites, aux terminaisons coupées net, avec sa griffe : un hameçon qui court sous le mot comme une ligne tendue. Le symbole carré `rose` reprend l'hameçon, dont l'œillet porte un point.

**Ce que tu fournis** : un fond parmi `bg`, `surface`, `brume`, `ink`, `rose`, `violet`, `blush`, `lilac`, et le fichier SVG correspondant (`assets/Logos/`).

- Utilise `hooka-lockup-ink.svg` (wordmark + griffe) sur `bg`, `surface`, `brume`, `rose`, `blush` et `lilac`.
- Utilise `hooka-lockup-cream.svg` sur `ink` (Jour), sur `bg` (Nuit) et sur `violet` (Jour).
- Utilise le wordmark seul quand la hauteur manque (en-tête, barre de navigation).
- Utilise `hooka-symbol.svg` pour l'icône d'app, l'avatar et le favicon, jamais sur un fond `rose`.
- Zone de protection : le diamètre d'un « o » autour du logo, jamais moins que `space-5`.
- Tailles minimales : 96 px de large pour le lockup, 72 px pour le wordmark, 32 px pour le symbole.

À ne pas faire : incliner ou arrondir le lettrage, détacher la griffe du mot, ajouter une ombre ou un contour, étirer le logo, remplacer un « o » par un globe ou une feuille, poser une version claire sur `rose` ou `blush` (contraste insuffisant), diriger l'hameçon vers un visage.
