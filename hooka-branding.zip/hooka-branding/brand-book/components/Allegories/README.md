Les allégories sont le petit monde illustré de Hooka : des objets du bord de l'eau détournés vers la pêche aux bonnes affaires. Elles égaient les écrans vides, les affiches, les réseaux et les pages de bienvenue.

**Ce que tu fournis** : le sens à illustrer (prise, recherche, bon plan local, petits pas, trouvaille) et un fond `bg`, `brume`, `blush` ou `lilac`. Choisis le fichier dans `assets/Illustrations/`.

- Une allégorie par bloc, taille minimale 96 px, jamais étirée, jamais recolorée.
- Place le titre en HTML autour d'elle, jamais à l'intérieur du SVG.
- L'étiquette-hameçon est le signe principal ; la scène de la mère de famille est réservée aux visuels de campagne et à l'accueil.

À ne pas faire : ajouter un animal (poisson, mouette ou autre), dessiner un hameçon tourné vers une personne, ajouter un visage ou une expression aux personnages, mélanger avec des photos de stock, utiliser une feuille ou un globe comme symbole d'écologie.
