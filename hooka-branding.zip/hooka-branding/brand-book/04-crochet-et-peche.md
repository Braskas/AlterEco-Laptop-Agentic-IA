# Crochet et pêche

## Le jeu de mots

« Faire un crochet » : se détourner de son chemin pour trouver une meilleure occasion. « Hook » : l'hameçon, et l'accroche. Hooka met les deux en scène : l'utilisateur lance la ligne depuis son téléphone et ramène la bonne affaire.

## Lexique de la pêche aux bonnes affaires

| Mot | Dans Hooka | Exemple |
|---|---|---|
| Faire un crochet | Le détour de 30 secondes | « Fais un crochet avant d'acheter neuf. » |
| Lancer la ligne | Lancer une recherche | Bouton : « Lancer la ligne » |
| Ça mord ! | Un bon plan est trouvé | « Ça mord : une gourde à 6 € à 300 m. » |
| La prise du jour | Le meilleur Hook du jour | « Ta prise du jour : un manteau taille M, gratuit. » |
| Le filet | Le Double Bonus du mois | « Ton filet du mois : 42 € gardés, 38 km évités. » |
| Le seau | Les petits pas déjà faits | « 12 prises dans ton seau. » |
| Le phare | Les bons plans près de chez toi | « Le phare du quartier : 3 Hooks à moins de 500 m. » |
| La Bande | L'entraide locale | inchangé |

Utilise ces mots avec parcimonie : un seul jeu de mots par écran, jamais dans un message d'erreur, de confiance ou de santé. Reste clair d'abord.

## Vigilance : hameçonnage

En français, « hameçonnage » veut dire phishing. Hooka ne le laisse jamais s'inviter dans sa voix.

- N'écris jamais « appât », « piéger », « mordre à l'hameçon » ou « se faire avoir » à propos de l'utilisateur.
- C'est toujours l'utilisateur qui pêche, et la prise est la bonne affaire. Jamais l'inverse.
- Ne dessine jamais un hameçon dirigé vers une personne ou vers un visage.
- Garde la Fiche de confiance visible : plus la métaphore est ludique, plus la transparence doit être nette (« Pourquoi ce choix ? »).
- Ne mets aucun lien « à cliquer vite » ou compte à rebours dans les campagnes.

## Aucun animal

On ne pêche que des bonnes affaires, pour le porte-monnaie ou la planète. Aucun poisson, aucune mouette, aucune faune dans les illustrations, les affiches, les animations et les emojis (il n'y en a pas).

## Phrases types

- « Fais un crochet. Trouve mieux. »
- « Hooka pêche la prochaine bonne affaire pour toi et la planète. »
- « Ça mord près de chez toi. »
- « Lance la ligne. 30 secondes, une prise. »
- « Un petit détour, un gros bon plan. »
